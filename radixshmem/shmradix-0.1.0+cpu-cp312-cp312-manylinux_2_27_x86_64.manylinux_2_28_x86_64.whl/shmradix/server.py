#!/usr/bin/env python3
"""
radix-server: Launch a RadixShmem KV cache server.

Single-node (standalone):
    radix-server --max-blocks 50000

Distributed cluster (run on each node):
    # Node 0 (master):
    radix-server --rank 0 --world-size 3 --master-addr 10.0.0.1 --master-port 18500 \\
                 --max-blocks 50000

    # Node 1:
    radix-server --rank 1 --world-size 3 --master-addr 10.0.0.1 --master-port 18500 \\
                 --max-blocks 50000

    # Node 2:
    radix-server --rank 2 --world-size 3 --master-addr 10.0.0.1 --master-port 18500 \\
                 --max-blocks 50000
"""

import argparse
import signal
import sys
import time

import shmradix


def fmt_size(nbytes: int) -> str:
    if nbytes >= 1 << 40:
        return f"{nbytes / (1 << 40):.2f} TB"
    if nbytes >= 1 << 30:
        return f"{nbytes / (1 << 30):.2f} GB"
    return f"{nbytes / (1 << 20):.2f} MB"


def parse_args() -> argparse.Namespace:
    p = argparse.ArgumentParser(
        prog="radix-server",
        description="RadixShmem KV cache server (standalone or distributed).",
    )

    g = p.add_argument_group("tree configuration")
    g.add_argument("--name", default="/shmradix",
                   help="Shared memory name or prefix (default: /shmradix)")
    g.add_argument("--max-blocks", type=int, default=0,
                   help="Mempool capacity in blocks, 0=disabled (default: 0)")
    g.add_argument("--block-size", type=int, default=1,
                   help="Tokens per block (default: 1)")
    g.add_argument("--max-nodes", type=int, default=0,
                   help="NodePool capacity, 0=auto (default: auto)")
    g.add_argument("--register-chunk-size", type=int, default=128,
                   help="RHT registration chunk size in blocks (default: 128)")
    g.add_argument("--evict-ratio", type=float, default=0.05,
                   help="Min eviction fraction per round, 0=on-demand (default: 0.05)")
    g.add_argument("--evict-policy", default="lru", choices=["lru"],
                   help="Eviction policy (default: lru)")
    g.add_argument("--background-evict", type=int, default=1, choices=[0, 1],
                   help="Background eviction thread (default: 1)")

    g = p.add_argument_group("distributed (world-size > 1 enables RDMA)")
    g.add_argument("--rank", type=int, default=0,
                   help="Node rank, 0=master (default: 0)")
    g.add_argument("--world-size", type=int, default=1,
                   help="Total number of nodes, 1=standalone (default: 1)")
    g.add_argument("--master-addr", default="127.0.0.1",
                   help="Master address for TCP bootstrap (default: 127.0.0.1)")
    g.add_argument("--master-port", type=int, default=18500,
                   help="Master port for TCP bootstrap (default: 18500)")
    g.add_argument("--rdma-dev", default="",
                   help="RDMA device name (default: first available)")
    g.add_argument("--gid-idx", type=int, default=3,
                   help="RDMA GID index for RoCE (default: 3)")
    g.add_argument("--bootstrap-timeout", type=int, default=60,
                   help="Bootstrap timeout in seconds (default: 60)")
    g.add_argument("--rdma-transport", default="xrc", choices=["xrc", "dc"],
                   help="Data-plane transport: xrc (full-mesh) | dc "
                        "(Dynamically Connected). Authoritative on rank 0 "
                        "(default: xrc). Env SHMRADIX_RDMA_TRANSPORT overrides.")
    g.add_argument("--num-shards", type=int, default=0,
                   help="RHT shard count M, 0=M==world-size (default: 0). "
                        "Authoritative on rank 0.")
    g.add_argument("--shard-holders", default="",
                   help="Comma-separated holder ranks, e.g. '0,2,4,6' "
                        "(default: ranks [0,M)). Authoritative on rank 0.")
    g.add_argument("--rht-slots", type=int, default=1, choices=[1, 2, 4, 8],
                   help="RHT slots per bucket W for collision chaining "
                        "(default: 1). Authoritative on rank 0. Env "
                        "SHMRADIX_RHT_SLOTS overrides.")

    g = p.add_argument_group("monitoring")
    g.add_argument("--interval", type=int, default=5,
                   help="Stats print interval in seconds, 0=silent (default: 5)")

    return p.parse_args()


_EVICT_POLICY_MAP = {
    "lru": shmradix.EvictPolicy.LRU,
}


def _build_config(args: argparse.Namespace) -> shmradix.RadixServerConfig:
    shm = shmradix.ShmConfig(
        max_nodes=args.max_nodes,
        max_blocks=args.max_blocks,
        block_size=args.block_size,
        register_chunk_size=args.register_chunk_size,
        evict_ratio=args.evict_ratio,
        background_evict=bool(args.background_evict),
        evict_policy=_EVICT_POLICY_MAP[args.evict_policy],
    )
    shm.max_nodes = shm.effective_max_nodes()

    cfg = shmradix.RadixServerConfig()
    cfg.name = args.name
    cfg.shm = shm
    cfg.rank = args.rank
    cfg.world_size = args.world_size
    cfg.master_addr = args.master_addr
    cfg.master_port = args.master_port
    cfg.rdma_dev = args.rdma_dev
    cfg.gid_idx = args.gid_idx
    cfg.bootstrap_timeout_sec = args.bootstrap_timeout
    cfg.register_chunk_size = args.register_chunk_size
    cfg.transport = args.rdma_transport
    cfg.num_shards = args.num_shards
    cfg.rht_slots_per_bucket = args.rht_slots
    if args.shard_holders.strip():
        cfg.shard_holders = [int(x) for x in args.shard_holders.split(",")
                             if x.strip()]
    return cfg


def _stats_loop(running_ref, interval: int, stats_fn) -> None:
    while running_ref():
        if interval <= 0:
            time.sleep(0.1)
            continue
        for _ in range(interval * 10):
            if not running_ref():
                return
            time.sleep(0.1)
        if not running_ref():
            return
        line = stats_fn()
        sys.stdout.write(f"\r{line}        ")
        sys.stdout.flush()


def _format_stats(server, args: argparse.Namespace) -> str:
    nodes = server.total_radix_nodes()
    blocks = server.total_blocks()
    dp = server.data_pool_utilization() * 100.0
    ins_ok = server.insert_success_count()

    tag = (f"[rank {args.rank}]" if args.world_size > 1
           else "[stats]")
    line = f"{tag} nodes={nodes}  blocks={blocks}  data_pool={dp:.1f}%"
    if args.max_blocks > 0:
        line += f"  mempool={server.mempool_used()}/{server.mempool_total()}"
    line += f"  ins_ok={ins_ok}"

    if args.world_size <= 1:
        err_np = server.insert_error_node_pool_count()
        err_dp = server.insert_error_data_pool_count()
        err_ht = server.insert_error_ht_pool_count()
        err = err_np + err_dp + err_ht
        if err > 0:
            line += f"  ins_err={err}(np={err_np},dp={err_dp},ht={err_ht})"
    return line


def main() -> None:
    args = parse_args()
    cfg = _build_config(args)

    if args.world_size > 1:
        print(f"Starting radix-server (rank {args.rank}/{args.world_size})...")
        print(f"  Master:         {args.master_addr}:{args.master_port}")
        print(f"  Max nodes:      {cfg.shm.max_nodes}")
        print(f"  Max blocks:     {args.max_blocks if args.max_blocks else '0 (disabled)'}")
        print(f"  RDMA device:    {args.rdma_dev or '(auto)'}")
        print()
    else:
        print("Starting radix-server (standalone)...")
        print(f"  Name:           {args.name}")
        print(f"  Max blocks:     {args.max_blocks if args.max_blocks > 0 else '0 (disabled)'}")
        print(f"  Block size:     {args.block_size} tokens")
        print(f"  Max nodes:      {cfg.shm.max_nodes}")
        print(f"  Register chunk: {args.register_chunk_size}")
        evict_info = f"{args.evict_ratio:.2f}"
        if args.evict_ratio <= 0:
            evict_info += " (on-demand only)"
        print(f"  Evict ratio:    {evict_info}")
        print(f"  Evict policy:   {args.evict_policy}")
        print(f"  Stats interval: {args.interval} s")
        print()

    server = shmradix.RadixServer(cfg)
    if not server.bootstrap():
        print("Bootstrap FAILED!", file=sys.stderr)
        sys.exit(1)

    if args.world_size > 1:
        print(f"Cluster ready.  rank={args.rank}/{args.world_size}  shm={server.shm_name()}")
    else:
        print(f"Server ready.  shm={server.shm_name()}")
    print("Press Ctrl+C to shutdown.\n")

    running = True

    def on_signal(signum, frame):
        nonlocal running
        running = False

    signal.signal(signal.SIGINT, on_signal)
    signal.signal(signal.SIGTERM, on_signal)

    _stats_loop(running_ref=lambda: running, interval=args.interval,
                stats_fn=lambda: _format_stats(server, args))

    if args.world_size > 1:
        print(f"\nShutting down cluster node {args.rank}...")
    else:
        print("\nShutting down server...")


if __name__ == "__main__":
    main()
